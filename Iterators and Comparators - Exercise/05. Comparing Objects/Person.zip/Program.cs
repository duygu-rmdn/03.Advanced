﻿using System;
using System.Collections.Generic;

namespace _05._Comparing_Objects
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<Person> people = new List<Person>();

            while (command != "END")
            {
                string[] splited = command.Split();
                string name = splited[0];
                int age = int.Parse(splited[1]);
                string town = splited[2];

                Person p = new Person(name, age, town);
                people.Add(p);

                command = Console.ReadLine();
            }
            int n = int.Parse(Console.ReadLine());
            int samePerson = 0;
            int notSamePerson = 0;

            Person comparetPerson = people[n - 1];
            foreach (Person person in people)
            {
                if (person.CompareTo(comparetPerson) == 0)
                {
                    samePerson++;
                }
                else
                {
                    notSamePerson++;
                }
            }
            if (samePerson > 1)
            {
                Console.WriteLine($"{samePerson} {notSamePerson} {people.Count}");
            }
            else
            {
                Console.WriteLine("No matches");
            }
        }
    }
}
